<?php

defined ('BASEPATH') OR exit('No akses');

class index extends CI_Controller{

  public function __construct(){
    parent::__construct();
    date_default_timezone_set('Asia/Makassar');
    $this->load->model('tujuan_model');
    $this->load->model('antri_model');
    $this->load->model('admin_model');
    $this->load->model('option_model');
    $this->load->helper('security');
  }

  public function index($status=1){

    $option = $this->option_model->ambil_option();

    $cek = $this->antri_model->cek_antri();
    $user = $this->antri_model->ambil_antri();

    $hari_ini = date('Y-m-d');
    $tanggal_terakhir = date('t', strtotime($hari_ini));

    $datas = $this->tujuan_model->ambil_semua_tujuan();

    $i=0;
    // echo "<pre>";
    for($option->jam_mulai; $option->jam_mulai <= $option->jam_tutup - $option->toleransi - $option->penanganan; $option->jam_mulai =$option->jam_mulai + $option->toleransi + $option->penanganan){
      if(!($option->jam_mulai >= $option->jam_istirahat_mulai && $option->jam_mulai < $option->jam_istirahat_selesai)){
          $tanggal[$i] = gmdate('H:i:s', $option->jam_mulai);
          // var_dump($tanggal[$i]);
          $i++;
      }
    }
    // echo "<pre>";
    // var_dump($tanggal);

    if($this->input->post('jam_antri')==NULL){
      $tanggal_dipilih = date('Y-m-d',strtotime('+1 day'));
    } else {
      $tanggal_dipilih = $this->input->post('tanggal');
    }

    $waktu_sudah_diambil = $this->antri_model->ambil_semua_antrian($tanggal_dipilih);
    foreach($waktu_sudah_diambil as $waktu_diambil){
      $i=0;
      foreach($tanggal as $tanggal1){
        if($waktu_diambil->jam == $tanggal1){
          // echo $i;
          // echo "<br>";
          $tanggal[$i]=NULL;
        }
        $i++;
      }
    }

    $tujuan = $this->tujuan_model->ambil_tujuan();

    $hari_ini = date('Y-m-d');
    $tanggal_terakhir = date('t', strtotime($hari_ini));

    $cek_hari = date('Y-m-d');

    $cek_hari = explode('-', $cek_hari);
    $cek_hari[2] = $this->input->post('tanggal');
    $cek_hari=implode('-', $cek_hari);

    $cek_hari = date('D', strtotime($cek_hari));

    if($this->input->post('tanggal') > $tanggal_terakhir || $this->input->post('tanggal') < date('d',strtotime('+1 day'))){
      $notif = 'Antrian untuk tanggal yang dipilih sudah penuh';
    } elseif($this->input->post('nama')==NULL || $this->input->post('id_tujuan')==NULL || $this->input->post('tanggal')==NULL){
      $notif = 'Lengkapi Form';
    } elseif($cek_hari == 'Sun' || $cek_hari == 'Sat'){
      $notif = 'Tidak beroperasi pada tanggal yang anda pilih';
    }

    $data_json['datas'] = $datas;
    $data_json['notif'] = $notif;
    $data_json['tanggal_terakhir'] = $tanggal_terakhir;
    $data_json['tanggal'] = $tanggal;

    $data_json = json_encode($data_json);

    echo $data_json;

    // $this->load->view('ambil_antrian_view', compact('datas','notif','tanggal_terakhir', 'tanggal'));
  }

  public function ambil_antrian2_view($status=1){

      $option = $this->option_model->ambil_option();

    $datas = $this->input->post();

    $this->load->view('ambil_antrian2_view', compact('datas','tanggal_terakhir','tujuan','tanggal'));
  }

  public function ambil_antrian(){
    $_POST = xss_clean($this->input->post());

    $hari_ini = date('Y-m-d');
    $tanggal_terakhir = date('t', strtotime($hari_ini));

    $cek_hari = date('Y-m-d');

    $cek_hari = explode('-', $cek_hari);
    $cek_hari[2] = $this->input->post('tanggal');
    $cek_hari=implode('-', $cek_hari);

    $cek_hari = date('D', strtotime($cek_hari));

    if($this->input->post('nama')==NULL || $this->input->post('id_tujuan')==NULL || $this->input->post('tanggal')==NULL){
      redirect(base_url('index.php/index/index/2'));
    } elseif($this->input->post('tanggal') > $tanggal_terakhir || $this->input->post('tanggal') < date('d',strtotime('+1 day'))){
      redirect(base_url('index.php/index/index/2'));
    } elseif($cek_hari == 'Sun' || $cek_hari == 'Sat'){
      redirect(base_url('index.php/index/index/3'));
    }

    $data = $this->antri_model->tambah_antrian();

    if($data['jam'] != 0){
      redirect(base_url('index.php/index/cek_tiket/'.$data['unique_id']));
    } else{
      redirect(base_url('index.php/index/index/0'));
    }

  }

  public function cek_tiket_view(){
    $this->load->view('cek_tiket_view');
  }

  public function cek_tiket($data = 0){
    $data1 = $this->antri_model->cek_antri_by_id($data);

    $this->load->view('tiket_view', compact('data1'));
  }

  public function tiket_view(){
    $this->load->view('tiket_view');
  }

  public function login_view(){
    $this->load->view('login_view');
  }

  public function cek_login(){
    $data=$this->admin_model->cek_admin();

    if($data == NULL){
      redirect(base_url('index.php/index/login_view'));
    } else{
      unset($data['password']);
      $data['status']='login';
      $this->session->set_userdata($data);
      redirect(base_url('index.php/admin/'));
    }
  }
}
