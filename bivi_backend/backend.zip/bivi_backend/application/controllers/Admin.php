
<?php

defined ('BASEPATH') OR exit('No akses');

class admin extends CI_Controller{

  public function __construct(){
    parent::__construct();

      if($this->session->userdata('status')!='login'){
        redirect(base_url('index.php/index/'));
      }
    date_default_timezone_set('Asia/Makassar');
    $this->load->model('antri_model');
    $this->load->model('tujuan_model');
    $this->load->model('option_model');
    $this->load->model('admin_model');
  }

  public function index($waktu=0){
    $datas = $this->antri_model->ambil_antri();
    $option = $this->option_model->ambil_option();

    foreach($datas as $data){
      $data->pertama = 'FALSE';
    }

    if($datas != NULL){

      $waktu_hapus = $this->antri_model->auto_hapus($datas[0]->id_antri);

      $waktu1['jam'] = substr($waktu_hapus->jam,0,2) *60;
      $waktu1['menit'] = substr($waktu_hapus->jam,3,2);
      $option2['toleransi'] = $option->toleransi /60;
      $option2['penanganan'] = $option->penanganan /60;

      $waktu_fix = $waktu1['jam'] + $waktu1['menit'] + $option2['toleransi'] +$option2['penanganan'];
      $waktu_sekarang = (date('G') * 60) + date('i');

      if($datas[0]->status_pengantri == 1){
        $waktu_refresh = $waktu_fix - $waktu_sekarang;
        $waktu_refresh *= 60;
      } elseif($datas[0]->status_pengantri == 0){
        $waktu_refresh = $waktu_fix - $waktu_sekarang - $option2['penanganan'];
        $waktu_refresh *= 60;
      }

      if ($waktu_fix <= $waktu_sekarang) {
        $this->antri_model->auto_selesai($datas[0]->id_antri);
        redirect(base_url('index.php/admin/index'));
      }


    }

    $option->toleransi = $option->toleransi / 60;
    $option->penanganan = $option->penanganan /60;

    if($waktu > 0){
      $waktu = ($option->toleransi + $option->penanganan + $waktu);
    } else {
      $waktu = $option->toleransi + $option->penanganan;
    }
    $waktu = $waktu * 60;

    $this->load->view('header_view');
    $this->load->view('daftar_antrian_view', compact('datas','waktu','option','waktu_refresh'));
  }

  public function antrian_selesai($id=0){
    if($id==0){
      redirect(base_url('index.php/admin/index'));
    }

    $waktu = $this->antri_model->antri_berikut($id);
    $this->antri_model->selesai($id);

    redirect(base_url('index.php/admin/index/'.$waktu));
  }

  public function field_antrian_selesai($id=0){
    $this->load->view('header_view');
    $this->load->view('ket_admin_view', compact('id'));
  }

  public function option_view(){
    $data= $this->option_model->ambil_option();

    $this->load->view('header_view');
    $this->load->view('option_view', compact('data'));
  }

  public function set_option(){
    $this->option_model->update_option();
    redirect(base_url('index.php/admin/option_view'));
  }

  public function logout(){
    $this->session->sess_destroy();
    redirect(base_url('index.php/index/'));
  }

  public function tambah_tujuan(){
    $this->load->view('header_view');
    $this->load->view('tambah_tujuan_view');
  }

  public function tambah_tujuan_act(){
    if($this->input->post('tujuan')==NULL){
      redirect(base_url('index.php/admin/tambah_tujuan'));
    }
    $this->tujuan_model->tambah_tujuan();
    redirect(base_url('index.php/admin/tujuan_list'));
  }

  public function tujuan_list(){
    $datas = $this->tujuan_model->ambil_semua_tujuan();

    $this->load->view('header_view');
    $this->load->view('tujuan_list', compact('datas'));
  }

  public function hapus_tujuan($id){
    $this->tujuan_model->hapus_tujuan($id);
    redirect(base_url('index.php/admin/tujuan_list'));
  }


  public function antri_selesai_view(){
    $datas = $this->antri_model->ambil_antrian_selesai();

    $this->load->view('header_view');
    $this->load->view('antrian_selesai_view', compact('datas'));
  }

  public function tambah_admin_view($status=0){

    if($status == 1){
      $notif='Lengkapi data Admin';
    } elseif($status ==2){
      $notif='Sukses';
    }

    $this->load->view('header_view');
    $this->load->view('tambah_admin_view', compact('notif','status'));
  }

  public function tambah_admin(){
    if($this->input->post('nama_admin') == NULL || $this->input->post('username')==NULL || $this->input->post('password')==NULL){
      redirect(base_url('index.php/admin/tambah_admin_view/1'));
    }
    $this->admin_model->tambah_admin();
    redirect(base_url('index.php/admin/tambah_admin_view/2'));
  }

  public function seluruh_antrian(){

    if($this->input->get('tanggal_yang_diminta') == 0 ){
      $tanggal = date('Y-m-d', strtotime('+1 day'));
    } else {
      $tanggal_yang_diminta = date('Y-m-d');

      $tanggal_yang_diminta = explode('-', $tanggal_yang_diminta);
      $tanggal_yang_diminta[2] = $this->input->get('tanggal_yang_diminta');

      $tanggal=implode('-', $tanggal_yang_diminta);
    }

    $datas = $this->antri_model->ambil_semua_antrian($tanggal);

    $hari_ini = date('Y-m-d');
    $tanggal_terakhir = date('t', strtotime($hari_ini));

    $this->load->view('header_view');
    $this->load->view('seluruh_antrian_view', compact('datas','tanggal_terakhir'));
  }

  public function ganti_password_view($status=0){
    if($status == 1){
      $notif = 'Password tidak sesuai';
    } elseif($status == 2){
      $notif = 'Password telah diganti';
    } elseif($status == 3){
      $notif = 'Password lama salah';
    }else{
      $notif = NULL;
    }

    $this->load->view('header_view');
    $this->load->view('ganti_password_view', compact('notif','status'));
  }

  public function ganti_password(){
    if($this->input->post('password_baru') != $this->input->post('konfirmasi_password_baru')){
      redirect(base_url('index.php/admin/ganti_password_view/1'));
    }

    $status =  $this->admin_model->ganti_password();

    redirect(base_url('index.php/admin/ganti_password_view/'.$status));
  }

  public function edit_tujuan($id){
    $this->tujuan_model->edit_tujuan($id);
    redirect(base_url('index.php/admin/tujuan_list'));
  }

  public function status_pengatri($id){
    $this->antri_model->status_pengatri($id);
    redirect(base_url('index.php/admin/index'));
  }
}
