<?php

defined('BASEPATH') OR exit ('No akses');

class antri_model extends CI_Model{

    public function ambil_semua_antrian($tanggal){

      $data = $this->db->select('*')
                      ->from('antri')
                      ->join('tujuan', 'tujuan.id_tujuan = antri.id_tujuan')
                      ->where(array('tanggal'=>$tanggal,'status'=>0))
                      ->order_by('tanggal', 'ASC')
                      ->order_by('jam', 'ASC')
                      ->get()
                      ->result();

      if($data == NULL) {
        $this->db->get('antri')->result();
      } else {

      }
      return $data;
    }

    public function ambil_antri(){
      return $this->db->select('*')
                      ->from('antri')
                      ->join('tujuan', 'tujuan.id_tujuan = antri.id_tujuan')
                      ->order_by('id_antri','ASC')
                      ->where(array('tanggal'=>date('Y-m-d'),'status'=>0))
                      ->get()
                      ->result();
    }

    public function cek_antri(){
      return  $this->db->limit(1)
                ->get_where('antri', array('tanggal'=>$this->session->userdata('tanggal'),'jam'=>$this->session->userdata('jam')))
                ->row();
    }

    public function cek_antri_by_id($data){

      ($this->input->post()==NULL) ? $data=$data : $data=$this->input->post('unique_id');


      return $this->db->select('*')
                      ->from('antri')
                      ->join('tujuan', 'antri.id_tujuan = tujuan.id_tujuan')
                      ->where(array('unique_id'=>$data))
                      ->get()
                      ->row();
    }

    public function tambah_antrian(){
      $tanggal_yang_diminta = date('Y-m-d');

      $tanggal_yang_diminta = explode('-', $tanggal_yang_diminta);
      $tanggal_yang_diminta[2] = $this->input->post('tanggal');
      $tanggal_yang_diminta=implode('-', $tanggal_yang_diminta);

      $antri_terakhir = $this->db->select('jam')
                                ->order_by('id_antri','DESC')
                                ->limit(1)
                                ->from('antri')
                                ->where(array('tanggal'=>$tanggal_yang_diminta))
                                ->get()
                                ->row();

      $data['id_antri'] = $antri_terakhir;
      $option = $this->db->get('option')
                ->row();

      $unique_id = uniqid();

        $this->db->insert('antri', array('nama'=>$this->input->post('nama'),'unique_id'=>$unique_id,'tanggal'=>$tanggal_yang_diminta,'jam'=>$jam_antri,'ket_user'=>$this->input->post('ket_user'),'id_tujuan'=>$this->input->post('id_tujuan'), 'jam'=>$this->input->post('jam_antri')));
        $data['jam'] = $this->input->post('jam_antri');
        $data['tanggal'] = $tanggal_yang_diminta;
        $data['unique_id'] = $unique_id;
      return $data;
    }

    public function antri_berikut($id){
      $antri_berikut = $this->db->limit(1)
                                ->select('jam')
                                ->where(array('id_antri'=>$id+1))
                                ->get('antri')
                                ->row();

      if($antri_berikut == NULL){
        $waktu = 0;
      } else {
        $antri_berikut1['jam'] = substr($antri_berikut1->jam,0,2) * 60;
        $antri_berikut1['menit'] = substr($antri_berikut1->jam,3,2);

        $waktu = $antri_berikut1['jam'] + $antri_berikut1['menit'];
      }

      return $waktu;
    }

    public function auto_hapus($id){
      return $this->db->limit(1)
                ->select('*')
                ->where(array('id_antri'=>$id))
                ->get('antri')
                ->row();
    }

    public function ambil_antrian_selesai(){
      return $this->db->select('*')
                      ->from('antri')
                      ->join('tujuan', 'antri.id_tujuan = tujuan.id_tujuan')
                      ->where(array('status'=>1))
                      ->order_by('tanggal', 'ASC')
                      ->order_by('jam', 'ASC')
                      ->get()
                      ->result();
    }

    public function selesai($id){
      $this->db->where(array('id_antri'=>$id))
                ->update('antri', array('status'=>1));
    }

    public function auto_selesai($id){
      $this->db->where(array('id_antri'=>$id))
              >update('antri', array('status'=>1,'ket_admin'=>'Waktu toleransi telah habis'));
    }

    public function status_pengatri($id){
      $this->db->where(array('id_antri'=>$id))
              ->update('antri', array('status_pengantri'=>1));
    }
}
