<?php

defined('BASEPATH') OR exit('No akeses');

class admin_model extends CI_Model{

  public function cek_admin(){
    return $this->db->get_where('admin', array('username'=>$this->input->post('username'),'password'=>md5($this->input->post('password'))))->row_array();
  }

  public function tambah_admin(){
    $this->db->insert('admin', array('nama_admin'=>$this->input->post('nama_admin'),'username'=>$this->input->post('username'),'password'=>md5($this->input->post('password'))));
  }

  public function ganti_password(){
   $t = $this->db->where(
      array(
        'password'=>md5($this->input->post('password_lama')),
        'id_admin'=>$this->session->userdata('id_admin')
      )
    )->update('admin', array('password'=>md5($this->input->post('password_baru'))));
    if($this->db->affected_rows() == 1){
      return 2;
    } else{
      return 3;
    }
  }

  

}
