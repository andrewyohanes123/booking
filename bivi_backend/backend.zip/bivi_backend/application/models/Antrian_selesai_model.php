<?php

defined('BASEPATH') OR exit('No akses');

class antrian_selesai_model extends CI_Model{

  public function pindah($id){
    $data=$this->db->select('*')
                    ->limit(1)
                    ->from('antri')
                    ->join('tujuan', 'tujuan.id_tujuan = antri.id_tujuan')
                    ->where('id_antri', $id)
                    ->get()
                    ->row();

    $this->db->insert('antrian_selesai', array('nama'=>$data->nama,'jam'=>$data->jam,'tanggal'=>$data->tanggal, 'tujuan'=>$data->tujuan, 'ket_admin'=>$this->input->post('ket_admin')));

    $this->db->delete('antri', array('id_antri'=>$id));
  }

  public function ambil(){
    return $this->db->select('*')
                    ->from('antrian_selesai')
                    ->order_by('id_antrian_selesai', "DESC")
                    ->get()
                    ->result();
  }


}
