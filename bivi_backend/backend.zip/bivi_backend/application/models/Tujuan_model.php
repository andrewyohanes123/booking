<?php

defined('BASEPATH') OR exit('No akses');

class tujuan_model extends CI_Model{

  public function ambil_semua_tujuan(){
    return $this->db->get_where('tujuan', array('status_tujuan'=>1))->result();
  }

  public function ambil_tujuan(){
    return $this->db->limit(1)
              ->select('tujuan')
              ->from('tujuan')
              ->where(array('id_tujuan'=>$this->input->post('id_tujuan')))
              ->get()
              ->row();
  }

  public function tambah_tujuan(){
     $this->db->insert('tujuan', array('tujuan'=>$this->input->post('tujuan')));
  }

  public function hapus_tujuan($id){
    $this->db->where(array('id_tujuan'=>$id))
             ->update('tujuan', array('status_tujuan'=>0));
  }

  public function edit_tujuan($id){
    $this->db->where(array('id_tujuan'=>$id))
             ->update('tujuan', array('tujuan'=>$this->input->post('tujuan')));
  }
}
